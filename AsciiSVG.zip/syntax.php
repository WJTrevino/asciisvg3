<?php
/**
 * Plugin Color: Sets new colors for text and background.
 *
 * @license GPL 2 http://www.gnu.org/licenses/gpl-2.0.html
 * @author  Mohammad Rahmani <m [dot] rahmani [at] aut [dot] ac [dot] ir>

 *  Rev. 0.20: Some bugs fixed, support for DokuWiki 2011-05-25a
 *  Date: Thursday, June 23, 2011

 */

// must be run within DokuWiki
if(!defined('DOKU_INC')) die();

if(!defined('DOKU_PLUGIN')) define('DOKU_PLUGIN',DOKU_INC.'lib/plugins/');
require_once(DOKU_PLUGIN.'syntax.php');

/**
 * All DokuWiki plugins to extend the parser/rendering mechanism
 * need to inherit from this class
 */
class syntax_plugin_asciisvg extends DokuWiki_Syntax_Plugin {

    /**
     * return some info
     */
    function getInfo(){
        return array(
            'author' => 'Mohammad Rahmani',
            'email'  => 'm.rahmani@aut.ac.ir',
            'date'   => '2008-08-03',
            'name'   => 'ASCIIsvg Plugin',
            'desc'   => 'Translating ASCII math notation to SVG graphics',
            'url'    => 'http://wiki.splitbrain.org/plugin:asciisvg',
                     );
    }

    function getType(){ return 'formatting'; }
    function getAllowedTypes() { return array('formatting', 'substition', 'disabled'); }
    function getSort(){ return 158; }
    function connectTo($mode) { $this->Lexer->addEntryPattern('<asvg.*?>(?=.*?</asvg>)',$mode,'plugin_asciisvg'); }
    function postConnect() { $this->Lexer->addExitPattern('</asvg>','plugin_asciisvg'); }

/**
     * Handle the match
     */
    public function handle($match, $state, $pos, &$handler){
        switch ($state) {
        case DOKU_LEXER_ENTER :
            list($width, $height) = preg_split("/\//u", substr($match, 6, -1), 2);
//            if ($width="") $width="200";
//            if ($height="") $height="200";
            break;
        case DOKU_LEXER_UNMATCHED :
            return array($state, $match);
            break;
        case DOKU_LEXER_EXIT :
            return array($state, '');
            break;
        }
        return array($state, array($width, $height));
    }

    /**
     * Create output
     */
     public function render($mode, &$renderer, $data) {
        if($mode != 'xhtml') return false;
        list($state, $match) = $data;
        switch ($state) {
        case DOKU_LEXER_ENTER :
            list($width, $height) = $match;
            $renderer->doc .= "<embed  src='d.svg' width='$width' height='$height'  script='";
            break;
        case DOKU_LEXER_MATCHED :
            break;
         case DOKU_LEXER_UNMATCHED :
            $renderer->doc .= $renderer->_xmlEntities($match);
            break;
         case DOKU_LEXER_EXIT :
            $renderer->doc .="'>";
            break;
        case DOKU_LEXER_SPECIAL :
            break;
        }
    }
}
?>
