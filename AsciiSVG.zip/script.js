/*
 This script installs the ASCIIsvg JavaScript
 to be used through "asciisvg" plugin in Dokuwiki
 @license GPL 2 http://www.gnu.org/licenses/gpl-2.0.html
 @author  Mohammad Rahmani <m [dot] rahmani [at] aut [dot] ac [dot] ir>

  Date: Sunday, 03 Aug. 2008  14:46:45
  Rev. 0: exprimental

 Rev. 0.2: Some bugs fixed
 Date: Thursday, June 23, 2011
   - all function in the previos script.js was deleted!
   - support for the latest version of Dokuwiki (2011-5-25a)
*/

// full address to ASCIIsvg main script
document.write('<script type="text/javascript" src="' + DOKU_BASE + '/lib/plugins/asciisvg/ASCIIsvg127.js' + '"></script>');
